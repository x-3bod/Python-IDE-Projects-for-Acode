# Python for Acode

Run Python 3.14 in the [Acode](https://acode.app) editor on Android. Python runs on your device through [Pyodide](https://pyodide.org), so no server or Termux setup is needed.

## Features

- **Run Python projects**: open a `.py` file and tap the run button; imports from other project `.py` files work
- **Project template**: create a starter project from Acode's **New Project → Python Project** template
- **Interactive console**: type Python after your program finishes; `input()` works too
- **Python packages**: `import numpy`, `pandas`, `matplotlib` and many more are downloaded automatically the first time you use them
- **Install from PyPI** with `micropip`
- **Plots and images**: `matplotlib` figures and Pillow images are shown right in the console
- **pygame (experimental)**: games draw to a canvas in the console
- **Copy output**: console text can be selected and copied
- **Line wrap**: toggle wrapping of long output lines from the header button
- **Progress indicator**: a thin line under the header shows while Python is loading or your code is running

## Usage

Open a Python file and tap the run button. The console shows your program's output, errors in red, and a prompt for `input()`.

### Python projects

In Acode's File Browser, choose **New Project → Python Project** for a starter folder, or open an existing project folder with **Open Folder**. Run its `main.py` normally; imports use Python's standard import system:

```python
from core.calculator import add

print(add(2, 3))
```

Before each run, the plugin synchronizes the active project’s `.py` files and unsaved Python tabs into Pyodide. For native `file://` and SAF workspaces it uses Acode's paginated `fileIndex` API when available; other providers and older Acode builds use `fsOperation`. If the file was opened directly, it uses only that file's containing folder. It skips `.git`, virtual environments, `__pycache__`, `node_modules`, `dist`, `build`, and common tool caches. Editing a module and rerunning the entry file reloads the project's modules.

The sync is limited to 500 Python files, 1 MiB per file, 8 MiB total Python source, and 20,000 scanned filesystem entries. Non-Python assets are not copied into Pyodide.

After the program finishes, you can keep typing Python in the console. Use the up and down arrows to browse previous commands and `Ctrl+L` to clear the console.

### Packages

Packages built for Pyodide (numpy, pandas, scipy, matplotlib, Pillow and [many more](https://pyodide.org/en/stable/usage/packages-in-pyodide.html)) load automatically when imported from the entry file or any synchronized project module. They are downloaded the first time, so an internet connection is needed then. This does not make native packages that are not built for Pyodide installable.

Pure Python packages from PyPI can be installed with `micropip`:

```python
import micropip
await micropip.install("snowballstemmer")

import snowballstemmer
print(snowballstemmer.stemmer("english").stemWords(["running", "jumps"]))
```

### Plots and images

`plt.show()` displays matplotlib figures in the console, and any figures still open are shown when the program ends. Figures default to the width of the console and are rendered sharp on high-density screens. Pillow's `Image.show()` works too.

```python
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 2 * np.pi, 200)
plt.plot(x, np.sin(x), label="sin(x)")
plt.legend()
plt.show()
```

### pygame (experimental)

pygame programs draw to a canvas in the console using Pyodide's [SDL support](https://pyodide.org/en/stable/usage/sdl.html). Ordinary game loops work as written:

```python
import pygame

pygame.init()
screen = pygame.display.set_mode((1280, 720))
clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill("purple")
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
```

- The display runs your program on Acode's main page instead of the isolated worker, so it could access the app and its data. The plugin asks before doing this (you can choose not to be asked again); only allow it for code you trust.
- Blocking loops like this need Android System WebView 137 or newer (JSPI support). On older WebViews, make the loop async with `await asyncio.sleep(0)` each frame.
- Running again or closing the console stops the game.
- If SDL cannot start, the program runs without a display and the console explains why.

## Limitations

- Only Python source files inside the active Acode project folder (or the active file's containing folder when opened directly) are synchronized. The plugin does not scan unrelated device storage.
- Code runs in Pyodide's browser sandbox: other device files are not exposed to Python, and `subprocess` and threads are unavailable.
- Packages with native code must be [built for Pyodide](https://pyodide.org/en/stable/usage/packages-in-pyodide.html); other native packages cannot be installed with `micropip`.
- Requires a recent Android System WebView.

## Development

```sh
npm install
npm run dev        # watch, serve on :3000, rebuild plugin.zip
npm run build      # bundle and write plugin.zip
npm run check      # lint and format check (Biome)
npm test           # project snapshot and Pyodide import tests
```

In Acode, install from **Plugins → + → Remote** using `http://<your-ip>:3000/plugin.zip`.

See [changelog.md](changelog.md) for release notes.
